$(function () {
    $('#monthYear').datepicker({
        format: 'dd/mm/yyyy',
        autoclose: true,
		minViewMode: 1
    });
});
