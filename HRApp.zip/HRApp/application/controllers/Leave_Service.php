<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!isset($_SESSION)){
    @session_start();
}

class Leave_Service extends CI_Controller {

	
	public function __construct() {
        parent::__construct();
        $this->load->model('leave_header_model');
        $this->load->model('leave_detail_model');
    }
	
	public function saveLeave()
	{
		$data = $this->input->post();
		
		if ($data['leave_id'] != "")
		{
			// Update
			$data['upd_date'] = date("Y-m-d H:i:s");
			$data['upd_by'] = $_SESSION["username"];
			$header_id = $this->leave_header_model->updateLeaveHeader($data);
			$this->leave_detail_model->deleteLeaveDetailByHeader($data['leave_id']);
		}
		else
		{
			// Insert
			$data['create_date'] = date("Y-m-d H:i:s");
			$data['create_by'] = $_SESSION["username"];
			$header_id = $this->leave_header_model->saveLeaveHeader($data);
		}
		
		$startdate_1 = $this->input->post("startLeave1");
		$enddate_1 = $this->input->post("endLeave1");
		$time_1 = $this->input->post("timeLeave1");
		$sum_1 = $this->input->post("sumLeave1");
		$detail_1 = $this->leave_detail_model->saveLeaveDetail($header_id,$startdate_1,$enddate_1,$time_1,$sum_1);
		
		
		if ($this->input->post("startLeave2") != "" && $this->input->post("sumLeave2") != "")
		{
			$startdate_2 = $this->input->post("startLeave2");
			$enddate_2 = $this->input->post("endLeave2");
			$time_2 = $this->input->post("timeLeave2");
			$sum_2 = $this->input->post("sumLeave2");
			$detail_2 = $this->leave_detail_model->saveLeaveDetail($header_id,$startdate_2,$enddate_2,$time_2,$sum_2);
		}
		
		echo json_encode($header_id);
	}
	
	public function deleteAttachment()
	{
		$data = $this->input->post();
		
		$dir_file = dirname(@$_SERVER['SCRIPT_FILENAME']) . "/asset/upload/files/" . $data['org'] . '/' . $data['user_id'] . "/" . $data['timeStamp']. "/" . $data['fileName'];
		try {
			if (!unlink($dir_file))
			{
			  echo json_encode("Error deleting $file");
			}
		} catch (Exception $e) {
			echo json_encode($e->getMessage());
		}
		
		echo json_encode(true);
		
	}
	
	public function listLeave()
	{
		$data = $this->input->get();
		$isHR = ($_SESSION["MyJob_name"] == "งานทรัพยากรบุคคล") && ($data['method'] == 'HR');
		
		if ($isHR)
			$emp_code = $data['emp_code'];
		else
			$emp_code = (int)$_SESSION["username"];
		
		$records = $this->leave_header_model->findLeaveByCondition($data['start_date'], $data['end_date'],$emp_code ,$isHR);
		foreach ($records as $record)
		{
			$record->attachment = "";
			if($record->leave_attachment != ""){
				$dirName = dirname(@$_SERVER['SCRIPT_FILENAME']) . '/asset/upload/files/' . $_SESSION["OfficeID"] . '/' . (int)$_SESSION["username"] . '/' . $record->leave_attachment;
				if (file_exists($dirName)) {
					if ($handle = opendir($dirName)) {
						while (false !== ($entry = readdir($handle))) {

							if ($entry != "." && $entry != ".." && $entry != "thumbnail") {

								$record->attachment .=  "<div><p><a target='_blank' href='" . base_url() . "asset/upload/files/" . $_SESSION["OfficeID"] . "/" . (int)$_SESSION["username"] . "/" . $record->leave_attachment . "/" . $entry ."'>". $entry . "</a></p></div><br>";
							}
						}
						closedir($handle);
					}
				} 	
			}
		}
	
		print_r(json_encode($records));
	}
	
	public function removeLeave()
	{
		$data = $this->input->get();
		$this->leave_detail_model->deleteLeaveDetailByHeader($data['leave_id']);
		$this->leave_header_model->deleteLeaveHeader($data['leave_id']);
		
		echo json_encode(0);
	}
	
	public function saveGrant1()
	{
		$data = $this->input->post();
		if(isset($data['grantList']) && sizeof($data['grantList']) > 0)
		{
			foreach ($data['grantList'] as $grant)
			{
				$this->leave_header_model->grantLeave1($grant['leave_id'] , $grant['approveValue'] , $grant['reason'] , $grant['sumleave'], (int)$_SESSION["username"]);
			}
		}		
		
		echo json_encode(true);
	}
	
	public function saveGrant2()
	{
		$data = $this->input->post();
		if(isset($data['grantList']) && sizeof($data['grantList']) > 0)
		{
			foreach ($data['grantList'] as $grant)
			{
				$this->leave_header_model->grantLeave2($grant['leave_id'] , $grant['approveValue'] , $grant['reason'] , $grant['sumleave'], (int)$_SESSION["username"]);
			}
		}		
		
		echo json_encode(true);
	}
	
	public function saveGrant3()
	{
		$data = $this->input->post();
		if(isset($data['grantList']) && sizeof($data['grantList']) > 0)
		{
			foreach ($data['grantList'] as $grant)
			{
				$this->leave_header_model->grantLeave3($grant['leave_id'] , $grant['approveValue'] , $grant['reason'] , $grant['sumleave'], (int)$_SESSION["username"]);
			}
		}		
		
		echo json_encode(true);
	}
	
	public function getLeaveSummary()
	{
		$current_year = date('Y');
		$holiday_year = $current_year;
		
		/*
		$sick_year = $current_year;
		if((time()-(60*60*24)) >= strtotime($current_year . '-07-01 00:00:00'))
		{
			$sick_year += 1;
		}
		*/
		if((time()-(60*60*24)) >= strtotime($current_year . '-10-01 00:00:00'))
		{
			$holiday_year += 1;
		}
		
		$data = array();
		$data["sick_year"] = '01 ต.ค.  ' . ($holiday_year - 1) . ' ถึง  30 ก.ย. ' . $holiday_year;
		$data["holiday_year"] = '01 ต.ค.  ' . ($holiday_year - 1) . ' ถึง   30 ก.ย. ' . $holiday_year;
		$data["sick_sum"] = $this->leave_header_model->getSummaryLeaveByCondition( '01/10/' . ($holiday_year - 1) , '30/09/' . $holiday_year , (int)$_SESSION["username"] , false);
		$data["holiday_sum"] = $this->leave_header_model->getSummaryLeaveByCondition( '01/10/' . ($holiday_year - 1) , '30/09/' . $holiday_year , (int)$_SESSION["username"] , true);
		
		echo json_encode($data);
	}
	
}
