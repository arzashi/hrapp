

            </section>
            <!-- /.content -->
        </div>
<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<strong>Copyright © 2017 : พัฒนาและออกแบบระบบโดย การประปาส่วนภูมิภาคเขต 1 </strong>		
	</div>
</footer>
</body>
</html>
