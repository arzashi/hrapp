<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['pwa1_base_url']	= 'http://localhost:88/pwa1/index.php/';
$config['pwa1_site_url']	= '';
?>
